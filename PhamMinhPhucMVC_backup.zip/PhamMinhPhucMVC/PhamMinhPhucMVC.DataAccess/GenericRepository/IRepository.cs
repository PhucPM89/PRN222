﻿using Microsoft.EntityFrameworkCore;
using PhamMinhPhucMVC.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace PhamMinhPhucMVC.DataAccess.GenericRepository
{
    public interface IRepository<T> where T : class
    {
        IEnumerable<T> GetAll();
        T GetById(object id);
        void Add(T entity);
        void Update(T entity);
        void Delete(object id);
        IEnumerable<T> Find(Func<T, bool> predicate);
        bool Any(Expression<Func<T, bool>> predicate);
    }
}
