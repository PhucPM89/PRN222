﻿using PhamMinhPhucMVC.Business.IService;
using PhamMinhPhucMVC.DataAccess.GenericRepository;
using PhamMinhPhucMVC.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhamMinhPhucMVC.Business.Service
{
    public class NewsArticleService : INewsArticleService
    {
        private readonly IRepository<NewsArticle> _newsRepository;
        private readonly IRepository<Tag> _tagRepository;

        public NewsArticleService(IRepository<NewsArticle> newsRepository, IRepository<Tag> tagRepository)
        {
            _newsRepository = newsRepository;
            _tagRepository = tagRepository;
        }
        public void CreateNews(NewsArticle news, List<short> tagIds)
        {
            news.CreatedDate = DateTime.Now;
            news.NewsStatus = true;

            foreach(var tagId in  tagIds)
            {
                var tag = _tagRepository.GetById(tagId);
                if (tag == null) throw new ArgumentException("Tag not found");
                news.Tags.Add(tag);
            }
            _newsRepository.Add(news);
        }

        public void DeleteNews(string id)
        {
            _newsRepository.Delete(id);
        }

        public List<NewsArticle> GetAllActiveNews()
        {
            return (List<NewsArticle>)_newsRepository.Find(n => n.NewsStatus == true);
        }

        public NewsArticle GetNewsByAuthor(short authorId)
        {
            return (NewsArticle)_newsRepository.Find(n => n.CreatedById == authorId);
        }

        public List<NewsArticle> GetNewsByDateRange(DateTime startDate, DateTime endDate)
        {
            return (List<NewsArticle>)_newsRepository.Find(n => n.CreatedDate >= startDate && n.CreatedDate <= endDate);
        }

        public NewsArticle GetNewsById(string id)
        {
            return _newsRepository.GetById(id);
        }

        public NewsArticle SearchNews(string keyword)
        {
            return (NewsArticle)_newsRepository.Find(n => (n.NewsTitle.Contains(keyword) || n.Headline.Contains(keyword) || n.NewsContent.Contains(keyword) || n.NewsStatus == true));
        }

        public void UpdateNews(NewsArticle news, List<short> tagIds)
        {
            var existingNews = _newsRepository.GetById(news.NewsArticleId);
            if (existingNews != null)
            {
                existingNews.NewsTitle = news.NewsTitle;
                existingNews.Headline = news.Headline;
                existingNews.NewsContent = news.NewsContent;
                existingNews.NewsSource = news.NewsSource;
                existingNews.CategoryId = news.CategoryId;
                existingNews.ModifiedDate = DateTime.Now;
                existingNews.UpdatedById = news.UpdatedById;

                existingNews.Tags.Clear();
                foreach(var tagId in tagIds)
                {
                    var tag = _tagRepository.GetById(tagId);
                    if(tag != null) existingNews.Tags.Add(tag);
                }
                _newsRepository.Update(existingNews);
            }
        }
	}
}
