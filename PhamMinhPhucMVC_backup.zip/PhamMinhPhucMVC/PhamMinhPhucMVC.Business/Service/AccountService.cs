﻿using Microsoft.Identity.Client;
using PhamMinhPhucMVC.Business.IService;
using PhamMinhPhucMVC.DataAccess.GenericRepository;
using PhamMinhPhucMVC.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhamMinhPhucMVC.Business.Service
{
    public class AccountService : IAccountService
    {
        public readonly IRepository<SystemAccount> _accountRepository;
        public AccountService(IRepository<SystemAccount> accountRepository) { 
            _accountRepository = accountRepository;
        }
        public void CreateAccount(SystemAccount account)
        {
            if(account == null) throw new ArgumentException(nameof(account));
            var existingAccount = GetAccountByEmail(account.AccountEmail);
            if (existingAccount != null) throw new InvalidOperationException("Email already exist");
            if (string.IsNullOrEmpty(account.AccountEmail) ||
                string.IsNullOrEmpty(account.AccountPassword) ||
                string.IsNullOrEmpty(account.AccountName))
                throw new ArgumentException("Required fields cannot be empty");
            var maxIdAccount = _accountRepository.Find(a => true).ToList();
            int newId = maxIdAccount.Any() ? maxIdAccount.Max(a => a.AccountId) + 1 : 1;
            account.AccountId = (short)newId;
            _accountRepository.Add(account);
        }

        public void DeleteAccount(short id)
        {
            var account = GetAccountById(id);
            if (account == null) throw new ArgumentException($"Account with ID {id} not found");
            if (IsAdmin(id)) throw new InvalidOperationException("Cannot delete admin account");
            _accountRepository.Delete(id);
        }

        public SystemAccount GetAccountByEmail(string email)
        {
            if (string.IsNullOrEmpty(email)) throw new ArgumentNullException(nameof(email));
            var accounts = _accountRepository.Find(a => a.AccountEmail.ToLower() == email.ToLower()).ToList();
            return accounts.FirstOrDefault();
        }

        public SystemAccount GetAccountById(short id)
        {
            return _accountRepository.GetById(id);
        }

        public List<SystemAccount> GetAllAccount()
        {
            return _accountRepository.GetAll().ToList();
        }

        public bool IsAdmin(short id)
        {
            var account = _accountRepository.GetById(id);
            return account?.AccountRole == 0;
        }

        public bool IsStaff(short id)
        {
            var account = _accountRepository.GetById(id);
            return account?.AccountRole == 2;
        }

        public bool IsUser(short id)
        {
            var account = _accountRepository.GetById(id);
            return account?.AccountRole == 1;
        }

        public List<SystemAccount> SearchAccount(string keyword)
        {
            if (string.IsNullOrEmpty(keyword)) return GetAllAccount();

            return _accountRepository.Find(a =>
                (a.AccountName != null && a.AccountName.Contains(keyword)) ||
                (a.AccountEmail != null && a.AccountEmail.Contains(keyword))).ToList();
        }

        public void UpdateAccount(SystemAccount account)
        {
            if (account == null)
                throw new ArgumentNullException(nameof(account));

            var existingAccount = GetAccountById(account.AccountId);
            if (existingAccount == null) throw new ArgumentException($"Account with ID {account.AccountId} not found");

            if (account.AccountEmail != existingAccount.AccountEmail)
            {
                var emailExists = GetAccountByEmail(account.AccountEmail);
                if (emailExists != null && emailExists.AccountId != account.AccountId) throw new InvalidOperationException("Email already exists");
            }

            if (IsAdmin(existingAccount.AccountId) && account.AccountRole != 0) throw new InvalidOperationException("Cannot change admin role");

            if (string.IsNullOrEmpty(account.AccountEmail) || string.IsNullOrEmpty(account.AccountName)) throw new ArgumentException("Required fields cannot be empty");

            if (string.IsNullOrEmpty(account.AccountPassword)) account.AccountPassword = existingAccount.AccountPassword;

            _accountRepository.Update(account);
        }

        public bool ValidateAccount(string email, string password)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password)) return false;

            var account = GetAccountByEmail(email);
            if (account == null) return false;

            return account.AccountPassword == password;
        }
    }
}
