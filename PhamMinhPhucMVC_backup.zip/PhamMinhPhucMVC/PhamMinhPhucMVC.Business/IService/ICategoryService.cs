﻿using PhamMinhPhucMVC.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhamMinhPhucMVC.Business.IService
{
    public interface ICategoryService
    {
        public List<Category> GetAllCategories();
        public List<Category> GetActiveCategories();
        public Category GetCategoryById(short id);
        public void CreateCategory(Category category);
        public void UpdateCategory(Category category);
        public bool DeleteCategory(short id);
        public List<Category> GetMainCategories();
        public List<Category> GetSubCategories(short parentId);
        public List<Category> SearchCategories(string keyword);
    }
}
