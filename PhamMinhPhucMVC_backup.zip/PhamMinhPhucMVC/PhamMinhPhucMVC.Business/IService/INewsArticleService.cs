﻿using PhamMinhPhucMVC.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhamMinhPhucMVC.Business.IService
{
    public interface INewsArticleService
    {
        public List<NewsArticle> GetAllActiveNews();
        public NewsArticle GetNewsByAuthor(short authorId);
        public NewsArticle GetNewsById(string id);
        public void CreateNews(NewsArticle news, List<short> tagIds);
        public void UpdateNews(NewsArticle news, List<short> tagIds);
        public void DeleteNews(string id);
        public NewsArticle SearchNews(string keyword);
        public List<NewsArticle> GetNewsByDateRange(DateTime startDate, DateTime endDate);
    }
}
