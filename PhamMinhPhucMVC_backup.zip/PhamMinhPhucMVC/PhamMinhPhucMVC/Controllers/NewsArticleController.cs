﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PhamMinhPhucMVC.Business.IService;
using PhamMinhPhucMVC.DataAccess.Models;

namespace PhamMinhPhucMVC.Controllers
{
    public class NewsArticleController : Controller
    {
        private readonly INewsArticleService _newsService;
        private readonly ICategoryService _categoryService;
        private readonly IAccountService _accountService;

        public NewsArticleController(INewsArticleService newsService, ICategoryService categoryService, IAccountService accountService)
        {
            _newsService = newsService;
            _categoryService = categoryService;
            _accountService = accountService;
        }

        [AllowAnonymous]
        public IActionResult Index(string searchString, short? categoryId)
        {
            try
            {
                var activeNews = _newsService.GetAllActiveNews();

                if (!string.IsNullOrEmpty(searchString))
                {
                    activeNews = activeNews.Where(n => n.NewsTitle.Contains(searchString)).ToList();
                }

                if (categoryId.HasValue && categoryId.Value > 0)
                {
                    activeNews = activeNews.Where(n => n.CategoryId == categoryId).ToList();
                }

                ViewBag.Categories = _categoryService.GetActiveCategories();
                return View(activeNews);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading news: " + ex.Message;
                return View(new List<NewsArticle>());
            }
        }


        public IActionResult Manage()
        {
            var accountId = short.Parse(User.FindFirst("AccountId")?.Value ?? "0");
            var news = _newsService.GetNewsByAuthor(accountId);
            return View(news);
        }

        [AllowAnonymous]
        public IActionResult Details(string id)
        {
            try
            {
                var news = _newsService.GetNewsById(id);
                if (news == null)
                {
                    return NotFound();
				}

				return View(news);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading news details: " + ex.Message;
                return RedirectToAction(nameof(Index));
            }
        }

        public IActionResult Create()
        {
            try
            {
                PrepareViewBagForNews();
                return View(new NewsArticle());
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error preparing news creation: " + ex.Message;
                return RedirectToAction(nameof(Manage));
            }
        }

        private void PrepareViewBagForNews()
        {
            ViewBag.Categories = new SelectList(_categoryService.GetActiveCategories(), "CategoryId", "CategoryName");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("NewsTitle,Headline,NewsContent,NewsSource,CategoryId")] NewsArticle news, List<short> tagIds)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var accountId = short.Parse(User.FindFirst("AccountId")?.Value ?? "0");
                    news.CreatedById = accountId;
                    news.NewsArticleId = Guid.NewGuid().ToString();

                    _newsService.CreateNews(news, tagIds);
                    TempData["SuccessMessage"] = "News article created successfully.";
                    return Json(new { success = true });
                }
                return Json(new { success = false, errors = ModelState.Values.SelectMany(v => v.Errors) });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        public IActionResult Edit(string id)
        {
            try
            {
                var news =  _newsService.GetNewsById(id);
                if (news == null)
                {
                    return NotFound();
                }

                var accountId = short.Parse(User.FindFirst("AccountId")?.Value ?? "0");
                if (news.CreatedById != accountId)
                {
                    return Unauthorized();
                }

                PrepareViewBagForNews();
                return View(news);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading news for edit: " + ex.Message;
                return RedirectToAction(nameof(Manage));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit([Bind("NewsArticleId,NewsTitle,Headline,NewsContent,NewsSource,CategoryId")] NewsArticle news, List<short> tagIds)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var accountId = short.Parse(User.FindFirst("AccountId")?.Value ?? "0");
                    news.UpdatedById = accountId;

                    _newsService.UpdateNews(news, tagIds);
                    TempData["SuccessMessage"] = "News article updated successfully.";
                    return Json(new { success = true });
                }
                return Json(new { success = false, errors = ModelState.Values.SelectMany(v => v.Errors) });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(string id)
        {
            try
            {
                var news = _newsService.GetNewsById(id);
                if (news == null)
                {
                    return NotFound();
                }

                var accountId = short.Parse(User.FindFirst("AccountId")?.Value ?? "0");
                if (news.CreatedById != accountId)
                {
                    return Unauthorized();
                }

                _newsService.DeleteNews(id);
                TempData["SuccessMessage"] = "News article deleted successfully.";
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [AllowAnonymous]
        public IActionResult Search(string keyword)
        {
            try
            {
                var news = _newsService.SearchNews(keyword);
                return PartialView("_NewsList", news);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [AllowAnonymous]
        public IActionResult FilterByDate(DateTime? startDate, DateTime? endDate)
        {
            try
            {
                if (!startDate.HasValue || !endDate.HasValue)
                {
                    return PartialView("_NewsList", _newsService.GetAllActiveNews());
                }

                var news = _newsService.GetNewsByDateRange(startDate.Value, endDate.Value);
                return PartialView("_NewsList", news);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
    }
}
