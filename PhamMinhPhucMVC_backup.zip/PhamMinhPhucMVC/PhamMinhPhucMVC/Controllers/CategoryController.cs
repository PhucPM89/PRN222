﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using PhamMinhPhucMVC.Business.IService;
using PhamMinhPhucMVC.Business.Service;
using PhamMinhPhucMVC.DataAccess.Models;

namespace PhamMinhPhucMVC.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ICategoryService _categoryService;

        public CategoryController(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }
        public IActionResult Index(string searchString)
        {
            try
            {
                var categories = string.IsNullOrEmpty(searchString) ? _categoryService.GetAllCategories() : _categoryService.SearchCategories(searchString);
                ViewBag.SearchString = searchString;
                return View(categories);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading categories: " + ex.Message;
                return View(new List<Category>());
            }
        }

        public IActionResult GetMainCategories()
        {
            try
            {
                var categories = _categoryService.GetMainCategories();
                return PartialView("_CategoryList", categories);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        public IActionResult GetSubCategories(short parentId)
        {
            try
            {
                var categories = _categoryService.GetSubCategories(parentId);
                return PartialView("_SubCategoryList", categories);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpGet]
        public IActionResult Create()
        {
            try
            {
                var categories = _categoryService.GetAllCategories();

                ViewBag.ParentCategories = new SelectList(categories, "CategoryId", "CategoryName");
                return View(new Category { IsActive = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error preparing category creation: " + ex.Message;
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("CategoryName,CategoryDesciption,ParentCategoryId,IsActive")] Category category)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _categoryService.CreateCategory(category);
                    TempData["SuccessMessage"] = "Category created successfully.";
                    return Json(new { success = true });
                }
                return Json(new { success = false, errors = ModelState.Values.SelectMany(v => v.Errors) });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

		[HttpGet]
		public IActionResult Edit(short id)
		{
			try
			{
				var category = _categoryService.GetCategoryById(id);
				if (category == null)
				{
					return NotFound();
				}
				ViewBag.ParentCategories = new SelectList(
					(_categoryService.GetMainCategories()).Where(c => c.CategoryId != id),
					"CategoryId",
					"CategoryName",
					category.ParentCategoryId);

				return View(category);
			}
			catch (Exception ex)
			{
				TempData["ErrorMessage"] = "Error loading category for edit: " + ex.Message;
				return RedirectToAction(nameof(Index));
			}
		}


		[HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Category category)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _categoryService.UpdateCategory(category);
                    TempData["SuccessMessage"] = "Category updated successfully.";
                    return Json(new { success = true });
                }
                return Json(new { success = false, errors = ModelState.Values.SelectMany(v => v.Errors) });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpGet]
        public IActionResult Delete(short id)
        {
            try
            {
                var category = _categoryService.GetCategoryById(id);
                if (category == null)
                {
                    return NotFound();
                }
                return View(category);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading category for delete: " + ex.Message;
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(short id)
        {
            try
            {
                var result = _categoryService.DeleteCategory(id);
                if (result)
                {
                    TempData["SuccessMessage"] = "Category deleted successfully.";
                    return Json(new { success = true });
                }
                else
                {
                    return Json(new { success = false, message = "Cannot delete category. It may have subcategories or associated news articles." });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        public IActionResult Search(string keyword)
        {
            try
            {
                var categories = _categoryService.SearchCategories(keyword);
                return PartialView("_CategoryList", categories);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        public IActionResult FilterActive(bool? isActive)
        {
            try
            {
                var categories = isActive.HasValue
                    ? _categoryService.GetActiveCategories()
                    : _categoryService.GetAllCategories();

                return PartialView("_CategoryList", categories);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        private IActionResult GetCategoryHierarchy()
        {
            try
            {
                var mainCategories = _categoryService.GetMainCategories();
                var hierarchy = new List<SelectListItem>();

                foreach (var main in mainCategories)
                {
                    hierarchy.Add(new SelectListItem { Value = main.CategoryId.ToString(), Text = main.CategoryName });

                    var subCategories = _categoryService.GetSubCategories(main.CategoryId);
                    foreach (var sub in subCategories)
                    {
                        hierarchy.Add(new SelectListItem { Value = sub.CategoryId.ToString(), Text = $"-- {sub.CategoryName}" });
                    }
                }

                return Json(hierarchy);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
    }
}
