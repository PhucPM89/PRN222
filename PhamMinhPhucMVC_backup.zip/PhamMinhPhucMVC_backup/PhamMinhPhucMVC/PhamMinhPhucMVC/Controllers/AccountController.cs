﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PhamMinhPhucMVC.Business.IService;
using PhamMinhPhucMVC.DataAccess.Models;
using System.Security.Claims;

namespace PhamMinhPhucMVC.Controllers
{
    //[Authorize(Roles = "Admin")]
    public class AccountController : Controller
    {
        private readonly IAccountService _accountService;
        private readonly IConfiguration _configuration;
        private readonly INewsArticleService _newsArticleService;

        public AccountController(IAccountService accountService, IConfiguration configuration, INewsArticleService newsArticleService)
        {
            _accountService = accountService;
            _configuration = configuration;
            _newsArticleService = newsArticleService;   
        }

        public IActionResult Index(string searchString)
        {
            try
            {
                var accounts = string.IsNullOrEmpty(searchString) ? _accountService.GetAllAccount() : _accountService.SearchAccount(searchString);
                ViewBag.SearchString = searchString;
                return View(accounts);
            }catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading accounts: " + ex.Message;
                return View(new List<SystemAccount>());
            }
        }

        public IActionResult Details(short id)
        {
            try
            {
                var account = _accountService.GetAccountById(id);
                if (account == null) return NotFound();
                return View(account);
            } catch(Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading accounts: " + ex.Message;
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(SystemAccount account)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _accountService.CreateAccount(account);
                    TempData["SuccessMessage"] = "Account created successfully.";
                    return Json(new { success = true });
                }
                return Json(new { success = false, errors = ModelState.Values.SelectMany(v => v.Errors) });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        public IActionResult Edit(short id)
        {
            try
            {
                var account =  _accountService.GetAccountById(id);
                if (account == null)
                {
                    return NotFound();
                }
                return View(account);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading account for edit: " + ex.Message;
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(SystemAccount account)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var existingAccount = _accountService.GetAccountById(account.AccountId);
                    if (existingAccount != null)
                    {
                        existingAccount.AccountName = account.AccountName;
                        existingAccount.AccountEmail = account.AccountEmail;
                        existingAccount.AccountRole = account.AccountRole;

                        _accountService.UpdateAccount(existingAccount);
                        TempData["SuccessMessage"] = "Account updated successfully.";
                        return Json(new { success = true });
                    }
                    return Json(new { success = false, message = "Account not found." });
                }
                return Json(new { success = false, errors = ModelState.Values.SelectMany(v => v.Errors) });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public IActionResult Login(string email, string password)
        {
            try
            {

                bool isValidUser =  _accountService.ValidateAccount(email, password);

                if (!isValidUser)
                {
                    var defaultEmail = _configuration["AdminAccount:Email"];
                    var defaultPassword = _configuration["AdminAccount:Password"];
                    var defaultRole = int.Parse(_configuration["AdminAccount:Role"]);

                    if (email == defaultEmail && password == defaultPassword)
                    {
                        var defaultAccount = _accountService.GetAccountByEmail(defaultEmail);
                        if (defaultAccount == null)
                        {
                            defaultAccount = new SystemAccount
                            {
                                AccountEmail = defaultEmail,
                                AccountName = "Administrator",
                                AccountRole = defaultRole
                            };
                            _accountService.CreateAccount(defaultAccount);
                        }

                        isValidUser = true;
                    }
                }

                if (isValidUser)
                {
                    var account =  _accountService.GetAccountByEmail(email);
                    var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, account.AccountName),
                    new Claim(ClaimTypes.Email, account.AccountEmail),
                    new Claim("AccountId", account.AccountId.ToString()),
                    new Claim(ClaimTypes.Role, GetRoleName(account.AccountRole))
                };

                    HttpContext.SignInAsync(
                        new ClaimsPrincipal(new ClaimsIdentity(claims, "Cookies")));

                    return RedirectToAction("Index", "Home");
                }

                ViewData["ErrorMessage"] = "Invalid email or password.";
                return View();
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = "Error during login: " + ex.Message;
                return View();
            }
        }

        private string GetRoleName(int? roleId)
        {
            return roleId switch
            {
                0 => "Admin",
                1 => "Staff",
                2 => "Lecturer",
                _ => "Unknown"
            };
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Logout()
        {
            HttpContext.SignOutAsync();
            return RedirectToAction("Login");
        }

        [HttpGet]
        public IActionResult SearchAccounts(string keyword)
        {
            try
            {
                var accounts = _accountService.SearchAccount(keyword);
                return PartialView("_AccountList", accounts);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        public IActionResult FilterByRole(int? role)
        {
            try
            {
                var accounts = _accountService.GetAllAccount();
                if (role.HasValue)
                {
                    accounts = (List<SystemAccount>)accounts.Where(a => a.AccountRole == role);
                }
                return PartialView("_AccountList", accounts);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpGet]
        public IActionResult Delete(short id)
        {
            try
            {
                var account = _accountService.GetAccountById(id);
                if (account == null)
                {
                    return NotFound();
                }
                return View(account); 
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading account for delete: " + ex.Message;
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(short AccountId)
        {

            try
            {
                var account = _accountService.GetAccountById(AccountId);
                if (account == null)
                {
                    return Json(new { success = false, message = "Account not found." });
                }

                _accountService.DeleteAccount(AccountId);

                TempData["SuccessMessage"] = "Account deleted successfully.";
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting account: {ex.Message}");
                return Json(new { success = false, message = ex.Message });
            }
        }
    }
}
