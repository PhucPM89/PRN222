﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PhamMinhPhucMVC.Business.IService;
using PhamMinhPhucMVC.Business.Service;
using PhamMinhPhucMVC.DataAccess.Models;

namespace PhamMinhPhucMVC.Controllers
{
    public class NewsArticleController : Controller
    {
        private readonly INewsArticleService _newsService;
        private readonly ICategoryService _categoryService;
        private readonly IAccountService _accountService;
        private readonly EmailService _emailService;

        public NewsArticleController(INewsArticleService newsService, ICategoryService categoryService, IAccountService accountService, EmailService emailService)
        {
            _newsService = newsService;
            _categoryService = categoryService;
            _accountService = accountService;
            _emailService = emailService;
        }

        [Authorize(Roles = "Staff")]
        public IActionResult Index(string searchString, short? categoryId)
        {
            try
            {
                var activeNews = _newsService.GetAllNews();

                var accountId = short.Parse(User.FindFirst("AccountId")?.Value ?? "0");

                if (accountId > 0)
                {
                    activeNews = activeNews.Where(n => n.CreatedById == accountId).ToList();
                }

                if (!string.IsNullOrEmpty(searchString))
                {
                    activeNews = activeNews.Where(n => n.NewsTitle.Contains(searchString)).ToList();
                }

                if (categoryId.HasValue && categoryId.Value > 0)
                {
                    activeNews = activeNews.Where(n => n.CategoryId == categoryId).ToList();
                }

                ViewBag.Categories = _categoryService.GetActiveCategories();
                return View(activeNews);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading news: " + ex.Message;
                return View(new List<NewsArticle>());
            }
        }


        public IActionResult Manage()
        {
            var accountId = short.Parse(User.FindFirst("AccountId")?.Value ?? "0");
            var news = _newsService.GetNewsByAuthor(accountId);
            return View(news);
        }

        [AllowAnonymous]
        public IActionResult Details(string id)
        {
            try
            {
                var news = _newsService.GetNewsById(id);
                if (news == null)
                {
                    return NotFound();
                }

                var category = _categoryService.GetCategoryById((short)news.CategoryId);
                var createdBy = _accountService.GetAccountById((short)news.CreatedById);
                var updatedBy = _accountService.GetAccountById(news.UpdatedById ?? 0);

                ViewBag.Category = category;
                ViewBag.CreatedByEmail = createdBy?.AccountEmail;
                ViewBag.UpdatedByEmail = updatedBy?.AccountEmail;

                return View(news);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading news details: " + ex.Message;
                return RedirectToAction(nameof(Index));
            }
        }

        public IActionResult Create()
        {
            try
            {
                PrepareViewBagForNews();
                return View(new NewsArticle());
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error preparing news creation: " + ex.Message;
                return RedirectToAction(nameof(Manage));
            }
        }

        private void PrepareViewBagForNews()
        {
            ViewBag.Categories = new SelectList(_categoryService.GetActiveCategories(), "CategoryId", "CategoryName");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("NewsTitle,Headline,NewsContent,NewsSource,CategoryId,NewsStatus")] NewsArticle news, List<short> tagIds)
        {
            try
            {
                var accountId = short.Parse(User.FindFirst("AccountId")?.Value ?? "0");
                news.CreatedById = accountId;
                news.NewsArticleId = Guid.NewGuid().ToString("N").Substring(0, 20);
                news.NewsStatus = Request.Form["NewsStatus"] == "on";

                _newsService.CreateNews(news, tagIds);

                var subject = $"New Article Published: {news.NewsTitle}";
                var body = $"A new article titled '{news.NewsTitle}' has been published by {User.Identity.Name}.\n\nYou can view the article here: https://localhost:7285/NewsArticle/Details/{news.NewsArticleId}";
                var adminEmail = "minhphuc2308033@gmail.com";

                _emailService.SendEmailAsync(adminEmail, subject, body);

                TempData["SuccessMessage"] = "News article created successfully.";
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        public IActionResult Edit(string id)
        {
            try
            {
                var news = _newsService.GetNewsById(id);
                if (news == null)
                {
                    return NotFound();
                }

                var accountId = short.Parse(User.FindFirst("AccountId")?.Value ?? "0");
                if (news.CreatedById != accountId)
                {
                    return Unauthorized();
                }

                PrepareViewBagForNews();
                return View(news);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading news for edit: " + ex.Message;
                return RedirectToAction(nameof(Manage));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit([Bind("NewsArticleId,NewsTitle,Headline,NewsContent,NewsSource,CategoryId,NewsStatus")] NewsArticle news, List<short> tagIds)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var accountId = short.Parse(User.FindFirst("AccountId")?.Value ?? "0");
                    news.UpdatedById = accountId;
                    news.NewsStatus = Request.Form["NewsStatus"] == "on";

                    _newsService.UpdateNews(news, tagIds);
                    TempData["SuccessMessage"] = "News article updated successfully.";
                    return Json(new { success = true });
                }
                return Json(new { success = false, errors = ModelState.Values.SelectMany(v => v.Errors) });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpGet]
        public IActionResult Delete(string id)
        {
            try
            {
                var news = _newsService.GetNewsById(id);
                if (news == null)
                {
                    return NotFound();
                }

                return View(news);
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error loading news for delete: " + ex.Message;
                return RedirectToAction(nameof(Index));
            }
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(string id)
        {
            try
            {
                var news = _newsService.GetNewsById(id);
                if (news == null)
                {
                    return NotFound();
                }

                _newsService.DeleteNews(id);

                TempData["SuccessMessage"] = "News article deleted successfully.";
                return RedirectToAction(nameof(Index)); 
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error deleting news article: " + ex.Message;
                return RedirectToAction(nameof(Index));
            }
        }


        [AllowAnonymous]
        public IActionResult Search(string keyword)
        {
            try
            {
                var news = _newsService.SearchNews(keyword);
                return PartialView("_NewsList", news);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [AllowAnonymous]
        public IActionResult ReportNews(DateTime? startDate, DateTime? endDate)
        {
            try
            {
                if (!startDate.HasValue || !endDate.HasValue)
                {
                    var allNews = _newsService.GetAllNews();
                    var result = new
                    {
                        News = allNews,
                        TotalCount = allNews.Count()
                    };
                    return View(result);
                }

                var news = _newsService.GetNewsByDateRange(startDate.Value, endDate.Value);
                var resultWithCount = new
                {
                    News = news,
                    TotalCount = news.Count()
                };

                return View(resultWithCount); 
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

    }
}
