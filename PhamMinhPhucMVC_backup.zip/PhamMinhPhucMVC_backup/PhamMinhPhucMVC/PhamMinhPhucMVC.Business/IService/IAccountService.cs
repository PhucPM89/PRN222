﻿using PhamMinhPhucMVC.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhamMinhPhucMVC.Business.IService
{
    public interface IAccountService
    {
        public List<SystemAccount> GetAllAccount();
        public SystemAccount GetAccountById(short id);
        public SystemAccount GetAccountByEmail(string email);
        public void CreateAccount(SystemAccount account);
        public void UpdateAccount(SystemAccount account);
        public void DeleteAccount(short id);
        public bool ValidateAccount(string email, string password);
        public List<SystemAccount> SearchAccount(string keyword);
        public bool IsAdmin(short id);
        public bool IsStaff(short id);
        public bool IsUser(short id);
    }
}
