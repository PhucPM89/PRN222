﻿using PhamMinhPhucMVC.Business.IService;
using PhamMinhPhucMVC.DataAccess.GenericRepository;
using PhamMinhPhucMVC.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhamMinhPhucMVC.Business.Service
{
    public class CategoryService : ICategoryService
    {
        private readonly IRepository<Category> _categoryRepository;
        private readonly IRepository<NewsArticle> _newsRepository;
        public CategoryService(IRepository<Category> categoryRepository, IRepository<NewsArticle> newsRepository)
        {
            _categoryRepository = categoryRepository;
            _newsRepository = newsRepository;
        }

        public void CreateCategory(Category category)
        {
            try
            {
                category.IsActive = true;
                if(category.ParentCategoryId.HasValue)
                {
                    var parentCategory = _categoryRepository.GetById(category.ParentCategoryId.Value);
                    if (parentCategory == null) throw new ArgumentException("Parent category not found");
                }
                _categoryRepository.Add(category);
            }catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public bool DeleteCategory(short id)
        {
            var category = _categoryRepository.GetById(id);
            if (category == null) throw new ArgumentException("Category not found");
            var hasNews = _newsRepository.Any(n => n.CategoryId == id);
            if (hasNews) return false;
            var hasSubCategory =  _categoryRepository.Any(c => c.ParentCategoryId == id);
            if(hasSubCategory) return false;
            _categoryRepository.Delete(id);
            return true;
        }

        public List<Category> GetActiveCategories()
        {
            return (List<Category>)_categoryRepository.Find(c => c.IsActive == true);
        }

        public List<Category> GetAllCategories()
        {
            return (List<Category>)_categoryRepository.GetAll();
        }

        public Category GetCategoryById(short id)
        {
            return _categoryRepository.GetById(id);
        }

        public List<Category> GetMainCategories()
        {
            return (List<Category>)_categoryRepository.Find(c => c.ParentCategoryId != null && c.IsActive == true);
        }

        public List<Category> GetSubCategories(short parentId)
        {
            return (List<Category>)_categoryRepository.Find(c => c.ParentCategoryId == parentId && c.IsActive == true);
        }

        public List<Category> SearchCategories(string keyword)
        {
            if (string.IsNullOrWhiteSpace(keyword)) return new List<Category>();
            return (List<Category>)_categoryRepository.Find(c => (c.CategoryName.Contains(keyword) || c.CategoryDesciption.Contains(keyword)) && c.IsActive == true);
        }

        public void UpdateCategory(Category category)
        {
            try
            {
                if(category.ParentCategoryId.HasValue)
                {
                    var parentCategory = _categoryRepository.GetById(category.ParentCategoryId.Value);
                    if (parentCategory == null) throw new ArgumentException("Parent category not found");
                    if (category.ParentCategoryId == category.CategoryId) throw new ArgumentException("Category cannot be it own parent");
                }

                var existingCategory = _categoryRepository.GetById(category.CategoryId);
                if (existingCategory == null) throw new ArgumentException("Category not found");

				existingCategory.CategoryName = category.CategoryName;
				existingCategory.CategoryDesciption = category.CategoryDesciption;
				existingCategory.ParentCategoryId = category.ParentCategoryId;
				existingCategory.IsActive = category.IsActive;

				_categoryRepository.Update(existingCategory);
			}
			catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
