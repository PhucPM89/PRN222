﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace PhamMinhPhucMVC.DataAccess.Models;

public partial class SystemAccount
{
    public short AccountId { get; set; }

    public string? AccountName { get; set; }
    [EmailAddress(ErrorMessage = "Invalid email format.")]
    public string? AccountEmail { get; set; }

    public int? AccountRole { get; set; }
    [StringLength(30, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters.")]
    public string? AccountPassword { get; set; }

    public virtual ICollection<NewsArticle> NewsArticles { get; set; } = new List<NewsArticle>();
}
